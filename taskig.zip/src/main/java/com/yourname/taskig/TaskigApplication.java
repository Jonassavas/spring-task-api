package com.yourname.taskig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskigApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskigApplication.class, args);
	}

}
