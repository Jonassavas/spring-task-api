package com.yourname.taskig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskigApplicationTests {

	@Test
	void contextLoads() {
	}

}
